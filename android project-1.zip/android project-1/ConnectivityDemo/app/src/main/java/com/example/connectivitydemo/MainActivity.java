package com.example.connectivitydemo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    ConnectivityManager connectivityManager;
    Button btn;
    ImageView imageview;
    TextView tv;
    boolean flag=false;
    MediaPlayer player;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = findViewById(R.id.btn);
        imageview=findViewById(R.id.imageview);
        tv=findViewById(R.id.tv);

        connectivityManager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
    }

    @Override
    protected void onStart() {
        checkWritePermissions();
        super.onStart();

    }

    private void checkWritePermissions()
    {
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)== PackageManager.PERMISSION_GRANTED)
        {
            flag=true;
            Toast.makeText(MainActivity.this,"permission granted",Toast.LENGTH_LONG).show();

        }
        else
        {
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},1);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==1)
        {
            if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED)
            {
                checkWritePermissions();
            }
            else
            {
                Toast.makeText(MainActivity.this,"permision denied",Toast.LENGTH_LONG).show();
            }
        }
    }

    public void CheckNetworkStatus(View view) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            Log.d("Tag","inside if");

            String textUrl="https://drive.google.com/uc?export=download&id=1JxnFMVLMoRgD2CFvpedjU0WpAqQjvSQr";
            String musicurl="https://drive.google.com/uc?export=download&id=1bbIROgy21zIu4toA2NTRJo_XedL8Ry9N";
            NetworkCapabilities capabilities=connectivityManager.getNetworkCapabilities(connectivityManager.getActiveNetwork());

            if(capabilities!=null)
            {
                Log.d("Tag","inside if");
                String imageurl="https://wallpapersite.com/images/pages/pic_w/6408.jpg";
                if(capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR))
                {
                    Log.d("Tag","inside if");
                    Toast.makeText(MainActivity.this,"mobile",Toast.LENGTH_LONG).show();
                }
                else if(capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI))
                {
                    Toast.makeText(MainActivity.this,"wifi",Toast.LENGTH_LONG).show();
                    //new MyImageTask().execute(imageurl);
                    //new MyText().execute(textUrl);
                    new MyImageTask().execute(musicurl);
                }
            }
            else
                Toast.makeText(MainActivity.this,"no active network present",Toast.LENGTH_LONG).show();

        } else {

            NetworkInfo info = connectivityManager.getActiveNetworkInfo();
            if (info != null) {
                if (info.getType() == ConnectivityManager.TYPE_WIFI) {
                    Toast.makeText(MainActivity.this, "WIFI", Toast.LENGTH_LONG).show();


                } else if (info.getType() == ConnectivityManager.TYPE_MOBILE) {
                    Toast.makeText(MainActivity.this, "MOBILE", Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(MainActivity.this, "NO network is present", Toast.LENGTH_LONG).show();
            }
        }
    }
    class MyMusicTask extends  AsyncTask<String,Void,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            return downloadMusic(strings[0]);
        }
        String downloadMusic(String path)
        {
            String s=null;
            try {
                URL myurl=new URL(path);
                HttpURLConnection httpURLConnection=(HttpURLConnection) myurl.openConnection();
                httpURLConnection.setRequestMethod("GET");
                httpURLConnection.setDoInput(true);
                httpURLConnection.connect();
                int code=httpURLConnection.getResponseCode();
                if(code==HttpURLConnection.HTTP_OK) {
                    InputStream stream = httpURLConnection.getInputStream();
                    if (stream != null) {
                        if(flag)
                        {
                            String state=Environment.getExternalStorageState();
                            if(state.equals(Environment.MEDIA_MOUNTED))
                            {
                                File root=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
                                File f1=new File(root,"mySong.mp3");
                                FileOutputStream fos=new FileOutputStream(f1);

                                int i=0;
                                while((i=stream.read())!=-1)
                                {
                                    fos.write(i);

                                }
                                Log.d("Tag","music file downloaded");
                                s="done";
                                fos.close();

                            }
                        }
                    }
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return s;
        }

        @Override
        protected void onPostExecute(String s) {
            if(s!=null)
            {

            }
        }
    }

    class MyText extends AsyncTask<String,Void,String>
    {

        @Override
         protected String doInBackground(String... strings) {
            return downloadText(strings[0]);
        }

       String  downloadText(String path)
       {
           String s=null;
           try
           {
               Log.d("Tag","inside try");
               URL myurl=new URL(path);
               HttpURLConnection httpURLConnection=(HttpURLConnection) myurl.openConnection();
               httpURLConnection.setRequestMethod("GET");
               httpURLConnection.connect();
               int code=httpURLConnection.getResponseCode();

               if(code==HttpURLConnection.HTTP_OK)
               {
                   InputStream stream=httpURLConnection.getInputStream();
                   if(stream != null)
                   {
                       BufferedReader reader=new BufferedReader(new InputStreamReader(stream));

                       String Line=" ";
                       String text=" ";
                       while((Line=reader.readLine())!=null)
                       {
                           text=text+Line+"\n";

                       }
                       s=text;
                       if(flag==true)
                       {
                           String state=Environment.getExternalStorageState();//to check wheather any space is avialable or not
                           if(state.equals(Environment.MEDIA_MOUNTED))
                           {
                               File root=Environment.getExternalStorageDirectory();
                               File f=new File(root,"Myfile.txt");
                               FileOutputStream fos=new FileOutputStream(f);//it also creates the file if these object doesnt exists
                               byte[] b=s.getBytes();
                               fos.write(b);
                               Log.d("Tag","file downloaded successfully");
                               Log.d("Tag","Path is"+f.getAbsolutePath());
                               fos.close();
                           }
                       }
                   }
               }
           } catch (MalformedURLException | ProtocolException e) {
               Log.d("Tag","in catch");

               e.printStackTrace();

           } catch (IOException e) {
               Log.d("Tag","Exception is "+e.getMessage());
               e.printStackTrace();
           }
           return s;
       }

        @Override
        protected void onPostExecute(String s) {
           if(s!=null)
           {
               tv.setText(s);
           }
        }
    }


    class MyImageTask extends AsyncTask<String,Void, Bitmap>
    {

        @Override
        protected Bitmap doInBackground(String... strings) {

           return downloadImage(strings[0]);
        }
        Bitmap downloadImage(String s)
        {
           Bitmap bitmap=null;

            try {
                URL myurl=new URL(s);
                HttpURLConnection httpURLConnection=(HttpURLConnection )myurl.openConnection();
                httpURLConnection.setReadTimeout(50000);
                httpURLConnection.setConnectTimeout(50000);
                httpURLConnection.setRequestMethod("GET");
                httpURLConnection.setDoInput(true);
                httpURLConnection.connect();
               int code= httpURLConnection.getResponseCode();
               if(code==HttpURLConnection.HTTP_OK)
               {
                  // Toast.makeText(MainActivity.this,"fine",Toast.LENGTH_LONG).show();
                   InputStream stream=httpURLConnection.getInputStream();
                   if(stream!=null)
                   {
                      bitmap=BitmapFactory.decodeStream(stream);
                   }
               }

            }
            catch (MalformedURLException e)
            {
               Log.d("hello",e.getMessage());

            } catch (IOException e)
            {
                e.printStackTrace();
            }


            return bitmap;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
           if(bitmap!=null)
           {
               imageview.setImageBitmap(bitmap);
           }
           else
           {
               Toast.makeText(MainActivity.this,"EMpty",Toast.LENGTH_LONG).show();
           }
        }
    }
}
//https://drive.google.com/uc?export=download&id=1JxnFMVLMoRgD2CFvpedjU0WpAqQjvSQr

