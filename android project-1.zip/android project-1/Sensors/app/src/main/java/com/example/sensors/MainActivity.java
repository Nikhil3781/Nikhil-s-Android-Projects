package com.example.sensors;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
TextView tv;
Button btn;
List<Sensor> sensorList;
Sensor lightSensor,proxySensor,tempSensor,accSensor,magSensor;
float [] accarr=new float[3];
float[] magarr=new float[3];


SensorManager sensorManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv=findViewById(R.id.tv);
        btn=findViewById(R.id.btn);

        sensorManager=(SensorManager) getSystemService(Context.SENSOR_SERVICE);
        sensorList=sensorManager.getSensorList(Sensor.TYPE_ALL);

        //intilization of the sensors
        lightSensor=sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
        proxySensor=sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);
       tempSensor=sensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE);
       accSensor=sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        magSensor=sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);


    }
//registering of the sensors
    @Override
    protected void onStart() {
        super.onStart();
        if(lightSensor!=null)
            sensorManager.registerListener(this,lightSensor,SensorManager.SENSOR_DELAY_NORMAL);
        if(proxySensor!=null)
            sensorManager.registerListener(this,proxySensor,SensorManager.SENSOR_DELAY_NORMAL);
        if(tempSensor!=null)
            sensorManager.registerListener(this,tempSensor,SensorManager.SENSOR_DELAY_NORMAL);
        if(accSensor!=null)
            sensorManager.registerListener(this,accSensor,SensorManager.SENSOR_DELAY_NORMAL);
        if(magSensor!=null)
            sensorManager.registerListener(this,magSensor,SensorManager.SENSOR_DELAY_NORMAL);
    }
//deregestering of the sensors
    @Override
    protected void onStop() {
        super.onStop();
        sensorManager.unregisterListener(this);//this line will unregister all the sensors at a time
        //sensorManager.unregisterListener(this,tempSensor);this line will only unregister the particular sensor(tempSensor)

    }

    public void showSensors(View view) {

        String text=" ";
        for(Sensor s:sensorList)
        {
           text=text+s.getName()+ "\n";//you can check anything like vendor etc any details


        }
        tv.setText(text);
    }

    @Override
    //whenever any new sensor is detected
    public void onSensorChanged(SensorEvent sensorEvent) {
        switch (sensorEvent.sensor.getType())
        {
            case Sensor.TYPE_AMBIENT_TEMPERATURE:

               float[] a=sensorEvent.values;
               tv.setText(" "+a[0]);
               if(a[0]>10)
               {
                   tv.setBackgroundColor(Color.GREEN);
               }
               else
                   tv.setBackgroundColor(Color.YELLOW);
                break;
                case Sensor.TYPE_ACCELEROMETER:
                //there will bethree vvalues present means the size of the array to be taken as three
                    accarr=sensorEvent.values;
                    break;
                case Sensor.TYPE_PROXIMITY:
                float[] proxyArr=sensorEvent.values;
                tv.setText(" "+proxyArr[0]);
                if(proxyArr[0]<=5)
                {
                    tv.setBackgroundColor(Color.BLUE);
                }
                else
                    tv.setBackgroundColor(Color.WHITE);

                break;
            case Sensor.TYPE_MAGNETIC_FIELD:
                magarr=sensorEvent.values;
                Toast.makeText(MainActivity.this,"This is Magnetic field sensor",Toast.LENGTH_LONG).show();
                break;
            case Sensor.TYPE_LIGHT:
                tv.setBackgroundColor(Color.GREEN);
                break;
        }
        float[] rotationarr=new float[9];
        boolean flag=sensorManager.getRotationMatrix(rotationarr,null,accarr,magarr);
        if(flag)
        {
            float[] orientationarr=new float[3];
            sensorManager.getOrientation(rotationarr,orientationarr);
            float azimuth=orientationarr[0];//z axis
            float pitch=orientationarr[1];//x axis
            float roll=orientationarr[2];//y axis
            tv.setText("Azimuth is"+azimuth+"\n Pitch is"+pitch+"\n Roll is"+roll);
        }
    }

    @Override
    //when chaniging the accuracy of the sensor
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}