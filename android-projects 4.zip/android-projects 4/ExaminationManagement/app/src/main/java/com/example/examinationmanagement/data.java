package com.example.examinationmanagement;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class data extends AppCompatActivity {
EditText edit1,edit2,phone_num,email;
Button btn;
Button btn1;
Button btn2;
    helper d;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);
        edit1=findViewById(R.id.edit1);
        edit2=findViewById(R.id.edit2);
        phone_num=findViewById(R.id.phone_num);
        email=findViewById(R.id.email);
        btn=findViewById(R.id.btn);
        btn1=findViewById(R.id.btn1);
        btn2=findViewById(R.id.btn2);

        d=new helper(getApplicationContext());
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                    String name=edit1.getText().toString();
                    long reg=Long.parseLong(edit2.getText().toString());

                    d.insertData(name,reg);
                    //Toast.makeText(data.this,"Details added successfully", Toast.LENGTH_LONG).show();

            }
        });
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(edit1.getText().toString().isEmpty() && edit2.getText().toString().isEmpty() && phone_num.getText().toString().isEmpty()
                        && email.getText().toString().isEmpty())
                {
                  Toast.makeText(getApplicationContext(),"pls fill all the details",Toast.LENGTH_LONG).show();
                }
                else{
               Intent i=new Intent(data.this,list_view.class);
               startActivity(i);
                }
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    Intent i=new Intent(data.this,application_form.class);
                    startActivity(i);
            }
        });


    }
}
