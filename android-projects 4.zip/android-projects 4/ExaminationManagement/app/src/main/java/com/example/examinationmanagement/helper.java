package com.example.examinationmanagement;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class helper extends SQLiteOpenHelper {
    static final String s="mydb";
    static final int dbv=1;
    Context c;
    public helper(@Nullable Context context) {
        super(context, s, null, dbv);
        c=context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String s="create table info(name text,reg long)";
       db.execSQL(s);
    }
    public void insertData(String name,long reg)
    {
        SQLiteDatabase sd=getWritableDatabase();
        ContentValues v=new ContentValues();
        v.put("name",name);
        v.put("reg",reg);
        long result= sd.insert("info",null,v);
        if(result==-1)
        {
            Toast.makeText(c,"failed",Toast.LENGTH_LONG).show();
        }
        else{
            Toast.makeText(c,"Added", Toast.LENGTH_LONG).show();}

    }
    public Cursor getData()
    {
     SQLiteDatabase sd=this.getReadableDatabase();
     String qwery ="SELECT * FROM info";
     Cursor data=sd.rawQuery(qwery,null);
     return data;
    }

    public void updateData(String name,long reg)
    {
        SQLiteDatabase sd=getWritableDatabase();
        String n="name = ?";
        ContentValues cv=new ContentValues();
        cv.put("reg",reg);
        String[] str={name};
        sd.update("info",cv,n,str);
        Toast.makeText(c,"Updated",Toast.LENGTH_LONG).show();
    }
    public void deleteData(String name)
    {
        SQLiteDatabase sd=getWritableDatabase();
        String n="name = ?";
        String []st={name};
        sd.delete("info",n,st);
        Toast.makeText(c,"deleted",Toast.LENGTH_LONG).show();

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
