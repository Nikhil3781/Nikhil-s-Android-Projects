package com.example.examinationmanagement;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class delete extends AppCompatActivity {
    helper d;
    Button btn;
    EditText edit1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);
        edit1=findViewById(R.id.edit1);
        btn=findViewById(R.id.btn);
        d=new helper(getApplicationContext());
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name=edit1.getText().toString();
                d.deleteData( name);
            }
        });
    }
}
