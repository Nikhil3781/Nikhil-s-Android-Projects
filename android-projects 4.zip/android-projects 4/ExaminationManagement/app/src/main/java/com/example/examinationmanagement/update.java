package com.example.examinationmanagement;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class update extends AppCompatActivity {
    Button btn;
    EditText edit1,edit2;
    helper d;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        btn=findViewById(R.id.btn);
        edit1=findViewById(R.id.edit1);
        edit2=findViewById(R.id.edit2);
        d=new helper(getApplicationContext());
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name=edit1.getText().toString();
                long reg=Long.parseLong(edit2.getText().toString());
                d.updateData(name,reg);


            }
        });

    }
}
