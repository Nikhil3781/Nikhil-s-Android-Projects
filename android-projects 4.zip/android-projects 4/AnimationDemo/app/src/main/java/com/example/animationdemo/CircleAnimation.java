package com.example.animationdemo;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;

public class CircleAnimation extends View {

    Paint mypaint;
    float x,y,radius;
    AnimatorSet mySet;

    public CircleAnimation(Context context, AttributeSet attrs) {
        super(context,attrs);
        mypaint=new Paint();
        mySet=new AnimatorSet();
    }
    public void setRadius(float radius)
    {
        this.radius=radius;
        mypaint.setColor(Color.CYAN-(int)(200*this.radius));
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        ObjectAnimator growAnimator=ObjectAnimator.ofFloat(this,"radius",0,getWidth());
        growAnimator.setDuration(5000);
        growAnimator.setInterpolator(new LinearInterpolator());
       // growAnimator.start();


        ObjectAnimator shrinkAnimator=ObjectAnimator.ofFloat(this,"radius",getWidth(),0);
        shrinkAnimator.setDuration(5000);
        shrinkAnimator.setStartDelay(2000);
        shrinkAnimator.setInterpolator(new DecelerateInterpolator());
        //shrinkAnimator.start();

        mySet.play(growAnimator).before(shrinkAnimator);
    }

    @Override
    protected void onDraw(Canvas canvas) {

       canvas.drawColor(Color.WHITE);
       canvas.drawCircle(x,y,radius,mypaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction())
        {
            case MotionEvent.ACTION_DOWN:
               x= event.getX();
               y=event.getY();
               if(mySet !=null && mySet.isRunning())
               {
                   mySet.cancel();
               }
               mySet.start();
               radius=100;
               break;
        }
        invalidate();
        return true;
    }
}
/* <com.example.animationdemo.CircleAnimation
        android:layout_width="match_parent"
        android:layout_height="500dp">
    </com.example.animationdemo.CircleAnimation>*/