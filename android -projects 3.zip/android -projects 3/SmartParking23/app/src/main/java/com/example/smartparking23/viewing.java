package com.example.smartparking23;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class viewing extends AppCompatActivity {
    ListView list;
   MyDatabase d;
   Button btn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewing);
        d=new MyDatabase(getApplicationContext());
        btn=findViewById(R.id.btn);
        list=findViewById(R.id.list);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ArrayList<String> al= d.viewList();
                ArrayAdapter<String> adapter=new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,al);
                list.setAdapter(adapter);
            }
        });
    }
}
