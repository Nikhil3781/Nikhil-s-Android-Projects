package com.example.smartparking23;

public class contact {
    String  name;
    int type;
    //int image;
    public contact(String name,int reg,int image)
    {
        //this.image=image;
        this.name=name;
        this.type=type;
    }
    public String getName()
    {
        return  name;
    }
    public int getType()
    {
        return type;
    }

}
