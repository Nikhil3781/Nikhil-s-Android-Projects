package com.example.smartparking23;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class data extends AppCompatActivity {
    Button btn1,btn2,btn3,btn4,btn5,btn6;
    EditText edit1,edit2,edit3,edit4,edit5;
    MyDatabase myDatabase;
    RecyclerView.LayoutManager lm;
    ArrayList<contact> al;
    //ArrayList<contact> al;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);
        edit1=findViewById(R.id.edit1);
        edit2=findViewById(R.id.edit2);
        edit3=findViewById(R.id.edit3);
       edit4=findViewById(R.id.edit4);
        edit5=findViewById(R.id.edit5);
        btn1=findViewById(R.id.btn1);
        //btn2=findViewById(R.id.btn2);

myDatabase=new MyDatabase(data.this);



        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String name1=edit1.getText().toString();
                long car_number=Long.parseLong(edit2.getText().toString());
                long phone_number=Long.parseLong(edit3.getText().toString());
                int type=Integer.parseInt(edit4.getText().toString());
                int time1=Integer.parseInt(edit5.getText().toString());

                myDatabase.insertData(name1,car_number,phone_number,type,time1);
                Toast.makeText(getApplicationContext(),"Your details are saved successfully",Toast.LENGTH_LONG).show();

                //Intent intent=new Intent(data.this,viewing.class);
                //startActivity(intent);
                myDatabase.viewList();


            }
        });
        /*btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(data.this,viewing.class);
                startActivity(intent);

            }
        });*/

    }
}
