package com.example.smartparking23;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class MyDatabase extends SQLiteOpenHelper {
    static final String s = "mydb";
    static final int dbv = 1;
    Context c;

    public MyDatabase(@Nullable Context context) {

        super(context, s, null, dbv);
        c = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table user(name String,car_number long,phone_number long,type int,time1 int)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void insertData(String name, Long car_number, Long phone_number, int type, int time1) {
        SQLiteDatabase sd = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("name", name);
        cv.put("car_number", car_number);
        cv.put("phone_number", phone_number);
        cv.put("type", type);
        cv.put("time", time1);

        sd.insert("user", null, cv);

    }

   /* public Cursor getData() {
        SQLiteDatabase sd = this.getReadableDatabase();
        //  String s = "Select * from info";
        Cursor cursor = sd.rawQuery("select * from user", null);
        return cursor;
        // String n = " ";
        // String s3 = null;
        // ArrayList<String> al = new ArrayList<>();
        //long l = 0;
        // while (cr.moveToNext()) {
        //     n = cr.getString(0);
        //    l = cr.getLong(1);
//            s3 += "Name is :" + n + "\n Mobile num :" + l + "\n";


        // }
        // Toast.makeText(c, "your data" + s3, Toast.LENGTH_LONG).show();

    }*/

    public ArrayList<String> viewList() {
        Toast.makeText(c, "Your details :", Toast.LENGTH_LONG).show();
        SQLiteDatabase sd = getReadableDatabase();

        String s = " ";
        long p = 0;
       // long phonenum = 0;
        //int a = 0;
       // int b = 0;

        String s3 = " ";
        String s1 = null;

        String g = "select * from user";
        Cursor cv = sd.rawQuery(g, null);
        ArrayList<String> al = new ArrayList<>();

        while (cv.moveToNext()) {
            s1 = cv.getString(0);
            p = cv.getLong(1);
           // phonenum = cv.getLong(2);
           // a = cv.getInt(3);
           // b = cv.getInt(4);

            s3 = s1 + " " + p ;
            /*String s9=s1;
            long car_num=p;
            long ph_num=phonenum;
            int type_wheel=a;
            int h=b;*/

            al.add(s3);


        }
        return al;

    }
}