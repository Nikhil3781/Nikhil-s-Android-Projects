package com.example.sqlitedatabase;

import android.content.ContentValues;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyHolder> {
    List<Person> personList;
    Context ct;


    MyAdapter(Context ct)
    {
       this.ct=ct;
    }
    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View myview= LayoutInflater.from(ct).inflate(R.layout.recylerview_layout,parent,false);

        return new MyHolder(myview);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, int position) {


        if(personList!=null) {
            Person person = personList.get(position);
            holder.text1.setText(person.getName());
            holder.text2.setText(""+person.getMob());
        }

    }

    @Override
    public int getItemCount() {
        if(personList!=null)
        {
            return personList.size();
        }
        else
            return 0;
    }
    public void setPersonList(List<Person> personList)
    {
        this.personList=personList;
        notifyDataSetChanged();
    }
    public Person getPersonAt(int position)
    {
        return  personList.get(position);
    }


    public class MyHolder extends RecyclerView.ViewHolder {
        TextView text1,text2;
        public MyHolder(@NonNull View itemView) {

            super(itemView);

            text1=itemView.findViewById(R.id.text1);
            text2=itemView.findViewById(R.id.text2);

        }
    }
}
