package com.example.sqlitedatabase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class NewPersonActivity extends AppCompatActivity {
EditText edit1,edit2;
Button btn;
public static final String Name_Extra="My extra name";
public static final String MyMessage="My extra mobile number";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_person);
        edit1=findViewById(R.id.edit1);
                edit2=findViewById(R.id.edit2);
                btn=findViewById(R.id.btn);
                btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if(TextUtils.isEmpty(edit1.getText().toString()))
                        {
                            edit1.setError("cant be empty");
                            return ;
                        }
                        if(TextUtils.isEmpty(edit2.getText().toString()))
                        {
                            edit2.setError("cant be empty");
                            return ;
                        }
                        Intent sendintent =new Intent();
                        sendintent.putExtra(Name_Extra,edit1.getText().toString());
                        sendintent.putExtra(MyMessage,edit2.getText().toString());
                        setResult(RESULT_OK,sendintent);
                        finish();

                    }
                });
    }
}
