package com.example.sqlitedatabase;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

public class PersonRepository {
    private PersonDOA mpersonDAO;

    private LiveData<List<Person>> mALLPerson;
    PersonRepository(Application application)
    {
        PersonDatabase database=PersonDatabase.getDatabase(application);
        mpersonDAO=database.getPersonDao();
        mALLPerson=mpersonDAO.getALLPerson();
    }
    public void insert(Person person)
    {
        new InsertPersonAsynctask(mpersonDAO).execute();
    }
    void update(Person p)
    {
        new UpdatePersonAsynctask(mpersonDAO).execute();
    }
    public void delete(Person p)
    {
        new DeletePersonAsynctask(mpersonDAO).execute();
    }
    public  void deleteALL()
    {
        new DeleteALLPersonAsynctask(mpersonDAO).execute();
    }
    LiveData<List<Person>> getmALLPerson()
    {
        return  mALLPerson;
    }
    class InsertPersonAsynctask extends AsyncTask<Person,Void,Void>
    {
        PersonDOA personDOA;
         InsertPersonAsynctask(PersonDOA dao)
         {
             personDOA=dao;
         }
        @Override
        protected Void doInBackground(Person... people) {
             personDOA.addPerson(people[0]);
            return null;
        }



    }
    class UpdatePersonAsynctask extends AsyncTask<Person,Void,Void>
    {
        PersonDOA personDOA;
        UpdatePersonAsynctask(PersonDOA doa)
        {
            personDOA=doa;
        }

        @Override
        protected Void doInBackground(Person... people) {
            personDOA.updatePerson(people[0]);
            return null;
        }
    }
    class DeletePersonAsynctask extends  AsyncTask<Person,Void,Void>
    {
     PersonDOA personDOA;
     DeletePersonAsynctask (PersonDOA doa)
     {
         personDOA=doa;
     }

        @Override
        protected Void doInBackground(Person... people) {
         personDOA.deletePerson(people[0]);
            return null;
        }
    }
    class DeleteALLPersonAsynctask extends  AsyncTask<Person,Void,Void>
    {
        PersonDOA personDOA;
        DeleteALLPersonAsynctask (PersonDOA doa)
        {
            personDOA=doa;
        }

        @Override
        protected Void doInBackground(Person... people) {
            personDOA.deleteALLPerson();
            return null;
        }
    }

}
