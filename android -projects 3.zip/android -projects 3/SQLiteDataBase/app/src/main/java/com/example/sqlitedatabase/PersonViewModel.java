package com.example.sqlitedatabase;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class PersonViewModel extends AndroidViewModel {
    private PersonRepository pRepository;
    private LiveData<List<Person>>mAllPerson;
    public PersonViewModel(@NonNull Application application) {
        super(application);
        pRepository=new PersonRepository(application);
        mAllPerson=pRepository.getmALLPerson();

    }
    LiveData<List<Person>>getALLPerson()
    {
        return mAllPerson;
    }
    public void insert(Person p)
    {
        pRepository.insert(p);
    }
    public void update(Person p)
    {
        pRepository.update(p);
    }
    public void delete(Person p)
    {
        pRepository.delete(p);
    }

    public void deleteAll()
    {
        pRepository.deleteALL();
    }

}
