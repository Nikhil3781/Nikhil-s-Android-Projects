package com.example.sqlitedatabase;

import android.content.Context;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

@Database( entities =(Person.class),version =1,exportSchema = false)
public abstract class PersonDatabase extends RoomDatabase {
    private static  PersonDatabase INSTANCE;
    public abstract PersonDOA getPersonDao();
    public static  synchronized PersonDatabase
    getDatabase(Context ct)
    {
        if(INSTANCE==null)
        {
            INSTANCE= Room.databaseBuilder(ct.getApplicationContext(),PersonDatabase.class,"person_database")
            .fallbackToDestructiveMigration()
            .addCallback(dabasecallback)
            .build();
        }
        return INSTANCE;
    }
    private static RoomDatabase.Callback dabasecallback =new RoomDatabase.Callback(){
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            new PopulateDbAsynctask(INSTANCE).execute();
        }


    };
    static class PopulateDbAsynctask extends AsyncTask<Void,Void,Void>
    {

        private PersonDOA personDAO;

        PopulateDbAsynctask(PersonDatabase personDatabase)
        {
            personDAO=personDatabase.getPersonDao();
        }
        @Override
        protected Void doInBackground(Void... voids) {
            personDAO.addPerson(new Person("Hello",111));
            personDAO.addPerson(new Person("Hello",222));
            personDAO.addPerson(new Person("Hello",333));
            return null;
        }
    }

}
