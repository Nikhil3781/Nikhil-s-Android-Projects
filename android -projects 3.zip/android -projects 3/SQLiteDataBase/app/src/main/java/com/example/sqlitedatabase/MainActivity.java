package com.example.sqlitedatabase;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.media.MediaRouter;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class MainActivity extends AppCompatActivity {
RecyclerView myrv;
MyAdapter adapter;
RecyclerView.LayoutManager layoutManager;
PersonViewModel personViewModel;
FloatingActionButton myfab;
public static final int myrequestcode=1;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myrv=findViewById(R.id.myrv);
        myfab=findViewById(R.id.myfab);
        adapter=new MyAdapter(this);
        layoutManager=new LinearLayoutManager(this);
        myrv.setLayoutManager(layoutManager);
        myrv.setAdapter(adapter);
        personViewModel= ViewModelProviders.of(this).get(PersonViewModel.class);
        personViewModel.getALLPerson().observe(this, new Observer<List<Person>>() {
            @Override
            public void onChanged(List<Person> people) {
                adapter.setPersonList(people);
            }
        });
        myfab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Click", Toast.LENGTH_LONG).show();
                Intent i=new Intent(MainActivity.this,NewPersonActivity.class);
                startActivityForResult(i,myrequestcode);

            }
        });
        //ItemTouchHelper itemTouchHelper=new ItemTouchHelper(new MediaRouter.SimpleCallback());




    }
    protected void onActivityResult(int requestCode,int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==myrequestcode)
        {
            if(resultCode ==RESULT_OK)
            {
                String name=data.getStringExtra(NewPersonActivity.Name_Extra);
                String mobile=data.getStringExtra(NewPersonActivity.MyMessage);
                Person p=new Person(name,Integer.parseInt(mobile));
                personViewModel.insert(p);
                Toast.makeText(this,"Person added",Toast.LENGTH_LONG).show();


            }
        }
    }
}
