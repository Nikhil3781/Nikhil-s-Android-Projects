package com.example.sqlitedatabase;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "person_table")
public class Person {
    @PrimaryKey(autoGenerate =true)
    private int id;

    @NonNull
    @ColumnInfo(name ="mob_coloumn")
    private int mob;

    @NonNull
    @ColumnInfo(name="name_column")
    private String name;
    public Person(@NonNull String name,@NonNull int mob)
    {
        this.name=name;
        this.mob=mob;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getMob() {
        return mob;
    }

    public void setMob(int mob) {
        this.mob = mob;
    }

    @NonNull
    public String getName() {
        return name;
    }

    public void setName(@NonNull String name) {
        this.name = name;
    }
}
