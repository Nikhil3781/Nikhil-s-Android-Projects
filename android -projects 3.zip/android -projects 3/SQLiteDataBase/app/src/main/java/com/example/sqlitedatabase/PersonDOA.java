package com.example.sqlitedatabase;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;
@Dao
public interface PersonDOA {
    @Insert
    void addPerson (Person p);

    @Delete
    void deletePerson(Person p);

    @Update
    void updatePerson(Person p);

    @Query("DELETE FROM person_table")

    void deleteALLPerson();

    @Query("SELECT * FROM person_table ORDER BY "+"name_column ASC")
    LiveData<List<Person>> getALLPerson();
}
