package com.example.animationdemo;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.graphics.drawable.AnimationDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
ImageView iv;
Button btn1,btn2,btn3,btn4,btn5,btn6;
AnimationDrawable animDrawable;
Animation anim,scaleanim,translatenanim,rotateanim;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        iv=findViewById(R.id.iv);
        btn1=findViewById(R.id.btn1);
        btn2=findViewById(R.id.btn2);
        btn3=findViewById(R.id.btn3);
        btn4=findViewById(R.id.btn4);
        btn5=findViewById(R.id.btn5);
        btn6=findViewById(R.id.btn6);

        iv.setBackgroundResource(R.drawable.myframeanimation);
       animDrawable=(AnimationDrawable) iv.getBackground();
       anim= AnimationUtils.loadAnimation(this,R.anim.mytweenanimation);
       scaleanim=AnimationUtils.loadAnimation(this,R.anim.myscaleanimation);
       translatenanim=AnimationUtils.loadAnimation(this,R.anim.mytranslateanimation);
       rotateanim=AnimationUtils.loadAnimation(this,R.anim.myrotationanimation);

    }

    public void DoFrameAnimation(View view) {
        switch (view.getId())
        {
            case R.id.btn1:
                if(!animDrawable.isRunning())

                    animDrawable.start();
                    break;



            case R.id.btn2:
                if(animDrawable.isRunning())

                    animDrawable.stop();
                    break;



        }
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void doTweenAnimation(View view) {
        switch (view.getId())
        {

            case R.id.btn3:
            //iv.startAnimation(anim);
              /*  AlphaAnimation aAnim=new AlphaAnimation(1.0f,0.0f);
                aAnim.setDuration(3000);
                aAnim.setRepeatCount(1);
                aAnim.setFillAfter(true);

                iv.startAnimation(aAnim);*/
               //property animation

                //alpha is a property of view
                //By using the java we are changing the property

               ObjectAnimator alphaAnimator=ObjectAnimator.ofFloat(iv,View.ALPHA,1.0f,0.0f);
               //ObjectAnimator alphaAnimator=ObjectAnimator.ofFloat(iv,"alpha",1.0f,0.0f);
                //first argument taken any object we can even pass the button object like iv=btn1;
                alphaAnimator.setDuration(4000);
                alphaAnimator.setRepeatCount(1);
                alphaAnimator.setRepeatCount(ObjectAnimator.REVERSE);
                alphaAnimator.start();
//by the xml property change
                /*Animator alphaAnimator=AnimatorInflater.loadAnimator(this,R.animator.property);
                alphaAnimator.setTarget(btn3);
                alphaAnimator.start();*/

                break;
            case R.id.btn4:
                //by xml
                //iv.startAnimation(scaleanim);
                //by java code
               /* ScaleAnimation sAnim=new ScaleAnimation(1.0f,4.0f,1.0f,3.0f,
                        Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF,0.5f);
                sAnim.setDuration(5000);
                iv.startAnimation(sAnim);*/
               //chaniging the property
                ObjectAnimator scaleAnimator=ObjectAnimator.ofFloat(btn4,View.SCALE_X,3.0f);
                //ObjectAnimator alphaAnimator=ObjectAnimator.ofFloat(iv,"alpha",1.0f,0.0f);
                //first argument taken any object we can even pass the button object like iv=btn1;
                scaleAnimator.setDuration(4000);
                scaleAnimator.setRepeatCount(1);
                scaleAnimator.setRepeatCount(ObjectAnimator.REVERSE);
              scaleAnimator.start();
                break;

            case R.id.btn5:
                /*TranslateAnimation tAnim=new TranslateAnimation(Animation.RELATIVE_TO_PARENT,
                        0.0f,Animation.RELATIVE_TO_PARENT,
                        0.0f,Animation.RELATIVE_TO_PARENT,0.0f,Animation.RELATIVE_TO_PARENT,1.0f);
                tAnim.setDuration(5000);
                iv.startAnimation(tAnim);*/
                //for translatioon

                AnimatorSet mySet=new AnimatorSet() ;

                ObjectAnimator transAnimator=ObjectAnimator.ofFloat(btn5,View.TRANSLATION_X,1000);
                //ObjectAnimator alphaAnimator=ObjectAnimator.ofFloat(iv,"alpha",1.0f,0.0f);
                //first argument taken any object we can even pass the button object like iv=btn1;
                transAnimator.setDuration(4000);
                transAnimator.setRepeatCount(1);
                transAnimator.setRepeatCount(ObjectAnimator.REVERSE);
                transAnimator.start();

               //for chaniging background color
               ObjectAnimator colorAnimator =ObjectAnimator.ofArgb(btn5,"backgroundColor",0X6200EE);
               colorAnimator.setRepeatCount(1);
               colorAnimator.setDuration(4000);
               //colorAnimator.start();
                colorAnimator.setRepeatMode(ObjectAnimator.REVERSE);
                //((AnimatorSet) mySet).play(transAnimator).with(colorAnimator);
               // ((AnimatorSet) mySet).start();
                mySet.play(transAnimator).with(colorAnimator);
                mySet.start();
                break;

            case R.id.btn6:
                //iv.startAnimation(rotateanim);
                RotateAnimation rAnim=new RotateAnimation(0,360,Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF,
                        0.5f);
                rAnim.setDuration(5000);
                iv.startAnimation(rAnim);
                break;
                //RotateAnimation rAnim=new RotateAnimation(Animation.)
            case R.id.btn7:
                AnimationSet animationSet=new AnimationSet(false);
                //animationSet.setInterpolator(new LinearInterpolator());
                TranslateAnimation tAnim1=new TranslateAnimation(Animation.RELATIVE_TO_PARENT,
                        0.0f,Animation.RELATIVE_TO_PARENT,
                        0.0f,Animation.RELATIVE_TO_PARENT,0.0f,Animation.RELATIVE_TO_PARENT,1.0f);
                tAnim1.setDuration(5000);
               // iv.startAnimation(tAnim1);



                RotateAnimation rAnim1=new RotateAnimation(0,360,Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF,
                        0.5f);
                rAnim1.setStartOffset(6000);
                rAnim1.setDuration(5000);
                //iv.startAnimation(rAnim1);
                animationSet.addAnimation(tAnim1);
                animationSet.addAnimation(rAnim1);
                iv.startAnimation(animationSet);
                break;
        }
    }


}