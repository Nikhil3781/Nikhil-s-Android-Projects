package com.example.firebasedemo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

public class UserProfile extends AppCompatActivity {
ImageView image;
Button btn;
TextView text;
FirebaseAuth auth;
DatabaseReference root;
StorageReference storageReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);
        image=findViewById(R.id.image);
        btn=findViewById(R.id.btn);
        text=findViewById(R.id.text);

        auth=FirebaseAuth.getInstance();
        root= FirebaseDatabase.getInstance().getReference();
         storageReference= FirebaseStorage.getInstance().getReference();

    }

    @Override
    protected void onStart() {
        super.onStart();
        auth.addAuthStateListener(new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                if(firebaseAuth.getCurrentUser() != null)
                {
                    image.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            openImage();
                        }
                    });
                    displayDetails();

                }
            }
        });
    }
    private void openImage()
    {
        Intent i=new Intent();
        i.setType("image/*");
        i.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(i,1);

    }
    public void onActivityResult(int requestCode,int resultCode,Intent data)
    {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==1 && resultCode==RESULT_OK)
        {
            if(data.getData()!=null)
            {
               Uri uri= data.getData();
               image.setImageURI(uri);
               uploadImageInFireBase(uri);
            }
        }
    }

    private void uploadImageInFireBase(Uri myuri) {
       StorageReference imageReference= storageReference.child(auth.getCurrentUser().getUid());
       imageReference.putFile(myuri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
           @Override
           public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
               Toast.makeText(UserProfile.this,"Image uploded successully",Toast.LENGTH_LONG).show();
           }
       }).addOnFailureListener(new OnFailureListener() {
           @Override
           public void onFailure(@NonNull Exception e) {
               Toast.makeText(UserProfile.this,e.getMessage(),Toast.LENGTH_LONG).show();
           }
       });
        {

        }
    }

    private void displayDetails()
    {
        root.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                 long oneMB=1024*1024;
                StorageReference sr= storageReference.child(auth.getCurrentUser().getUid());
                sr.getBytes(oneMB).addOnSuccessListener(new OnSuccessListener<byte[]>() {
                    @Override
                    public void onSuccess(byte[] bytes) {

                     Bitmap retriveImage=   BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                        image.setImageBitmap(retriveImage);
                        //Toast.makeText(UserProfile.this,)

                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(UserProfile.this,e.getMessage(),Toast.LENGTH_LONG).show();
                    }
                });


             DataSnapshot currentChild=   dataSnapshot.child(auth.getCurrentUser().getUid());//to reach the specific child
             String getInfo=currentChild.getValue(String.class);//the value is in the form of String(name)
             text.setText("\n"+getInfo);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        auth.signOut();
        startActivity(new Intent(UserProfile.this,Login.class));
        finish();

    }

    public void doAdd(View view) {

        AlertDialog.Builder alertDialog=new AlertDialog.Builder(this);
        View layoutView = getLayoutInflater().inflate(R.layout.mylayout,null);
        final EditText etype=layoutView.findViewById(R.id.edit);
        alertDialog.setView(layoutView);
       alertDialog.setPositiveButton("Save", new DialogInterface.OnClickListener() {
           @Override
           public void onClick(DialogInterface dialog, int i) {
               String newInfo=etype.getText().toString();
               String uid=auth.getCurrentUser().getUid();
               root.child(uid).setValue(text.getText().toString()+" \n"+newInfo);
           }
       });
        alertDialog.show();

    }
}