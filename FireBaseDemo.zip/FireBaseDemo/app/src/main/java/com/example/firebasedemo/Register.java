package com.example.firebasedemo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Register extends AppCompatActivity {
EditText edit1,edit2,edit3,edit4;
Button btn;
FirebaseAuth auth;
DatabaseReference root;
    ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        edit1=findViewById(R.id.edit1);
        edit2=findViewById(R.id.edit2);
        edit3=findViewById(R.id.edit4);
        edit4=findViewById(R.id.edit4);
        btn=findViewById(R.id.btn);
        auth=FirebaseAuth.getInstance();
        root= FirebaseDatabase.getInstance().getReference();

    }

    public void doRegister(View view) {
        final String name=edit1.getText().toString();
        String email=edit2.getText().toString();
        String password=edit3.getText().toString();
        String password2=edit4.getText().toString();

        if(TextUtils.isEmpty(email))
        {
            edit2.setError("Email Required");
            edit2.requestFocus();
            return;
        }

        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches())
        {
            edit2.setError("Email is not valid");
            edit2.requestFocus();
            return;
        }
        if(TextUtils.isEmpty(password))
        {
            edit3.setError("Password  Required");
            edit3.requestFocus();
            return;
        }
        if(password.length() <6)
        {
            edit3.setError("Password  must be  6 char");
            edit3.requestFocus();
            return;
        }

        progressDialog=new ProgressDialog(Register.this);
        //show dialogprogress
        progressDialog.show();
        //set content view
        progressDialog.setContentView(R.layout.progress_bar_1);
        //set transparent background
        progressDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        auth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful())
                {
                    String uid= auth.getCurrentUser().getUid();
                    root.child(uid).setValue(name);
                    Toast.makeText(Register.this,"User Account Created", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(Register.this,Login.class));
                    //finish();
                }
                else
                {
                    Toast.makeText(Register.this,task.getException().getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });


    }
}