package com.example.firebasedemo;

public class User {
    String name;
    int mobile;

    public User() {
    }

    public User(String name, int mobile) {
        this.name = name;
        this.mobile = mobile;
    }

    public int getMobile() {
        return mobile;
    }

    public String getName() {
        return name;
    }
}
