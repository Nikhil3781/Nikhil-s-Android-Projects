package com.example.firebasedemo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity {
EditText edit2,edit1;
Button btn;
TextView text1,text2;
ProgressDialog progressDialog;
    FirebaseAuth auth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        edit1=findViewById(R.id.edit1);
        edit2=findViewById(R.id.edit2);
        btn=findViewById(R.id.btn);
        text1=findViewById(R.id.text1);
        text2=findViewById(R.id.text2);

        auth=FirebaseAuth.getInstance();

    }

    @Override
    protected void onStart() {

        super.onStart();
        auth.addAuthStateListener(new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                if(firebaseAuth.getCurrentUser() !=null)
                {
                    Intent i=new Intent(Login.this,UserProfile.class);
                    startActivity(i);
                    Toast.makeText(Login.this,"User is not null",Toast.LENGTH_LONG).show();
                }
            }
        });
        //monitores the state of the user
    }

    public void gotoRegister(View view) {
        Intent intent=new Intent(Login.this,Register.class);
        startActivity(intent);
    }

    public void doLogin(View view) {

        String email=edit1.getText().toString();
        String password=edit2.getText().toString();
        //String password2=edit4.getText().toString();

        if(TextUtils.isEmpty(email))
        {
            edit1.setError("Email Required");
            edit1.requestFocus();
            return;
        }

        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches())
        {
            edit1.setError("Email is not valid");
            edit1.requestFocus();
            return;
        }
        if(TextUtils.isEmpty(password))
        {
            edit2.setError("Password  Required");
            edit2.requestFocus();
            return;
        }
        if(password.length() <6)
        {
            edit2.setError("Password  must be atleast 6 char");
            edit2.requestFocus();
            return;
        }
        //initilisation
        progressDialog=new ProgressDialog(Login.this);
        //show dialogprogress
        progressDialog.show();
        //set content view
        progressDialog.setContentView(R.layout.progress_bar);
        //set transparent background
        progressDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        auth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful())
                {
                    Toast.makeText(Login.this,"Login Successfully",Toast.LENGTH_LONG).show();
                    Intent intent=new Intent(Login.this,UserProfile.class);
                    startActivity(intent);
                    finish();
                }
                else
                {
                    Toast.makeText(Login.this,task.getException().getMessage(), Toast.LENGTH_LONG).show();

                }
            }
        });
    }
}