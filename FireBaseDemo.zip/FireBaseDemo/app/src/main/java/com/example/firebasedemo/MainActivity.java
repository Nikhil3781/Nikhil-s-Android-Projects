package com.example.firebasedemo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
DatabaseReference myref;
EditText edit1,edit2;
Button btn,btn2;
TextView text;
static int count=1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myref= FirebaseDatabase.getInstance().getReference();
        edit1=findViewById(R.id.edit1);
        edit2=findViewById(R.id.edit2);
        btn=findViewById(R.id.btn);
        btn2=findViewById(R.id.btn2);
        text=findViewById(R.id.text);


    }

    public void doWrite(View view) {

        String getName=edit1.getText().toString();
        int getMobile=Integer.parseInt(edit2.getText().toString());
        User currentUser=new User(getName,getMobile);
        //String getEmail=edit2.getText().toString();
        //myref.child("Email").setValue(getEmail);
        /*myref.child("Name").setValue(getName).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful())
                {
                    Toast.makeText(MainActivity.this,"insertion done",Toast.LENGTH_LONG).show();
                }
            }
        });*/
      myref.child("User"+count).setValue(currentUser);
      count++;

                //For writing any value to the database we use this method.
    }

    public void doRead(View view) {
        myref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {



               Iterable <DataSnapshot> iterable= dataSnapshot.getChildren();
               String s=" ";
               /*for(DataSnapshot ir:iterable)
               {
                   String getName=ir.getValue(String.class);
                   s=s+getName+"\n";
               }*/
               for(DataSnapshot td:iterable)
               {
                   User fetchUser=td.getValue(User.class);
                   int mob=fetchUser.getMobile();
                   String name=fetchUser.getName();
                   s=s+" "+name+" "+mob+"\n";
               }

             text.setText(""+s);
            }
//datasnapshot is a class which stores all the data from the real time data base
// in the form of key and value pair(
//if .child() is taken it only monitors that child node only and to monoitor all the node we use
//myref.addOnChangeListener()
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
